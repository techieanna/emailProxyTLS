import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EmailListener {

    public static void main(String[] args) {

        // Load properties from file
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Get configuration parameters from properties
        String host = properties.getProperty("smtp.host");
        int port = Integer.parseInt(properties.getProperty("smtp.port"));
        String auth = properties.getProperty("smtp.auth");
        String starttls = properties.getProperty("smtp.starttls");
        String senderEmail = properties.getProperty("sender.email");
        String senderPassword = properties.getProperty("sender.password");

        // Create properties object and configure SMTP server properties
        properties = new Properties();
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.auth", auth);
        properties.put("mail.smtp.starttls.enable", starttls);

        // Create Session object with authentication
        Session session = Session.getInstance(properties,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(senderEmail, senderPassword);
                    }
                });

        // Set up the listener for incoming emails
        try {
            ServerSocket serverSocket = new ServerSocket(Integer.parseInt(properties.getProperty("listener.port")));
            System.out.println("Listening for incoming emails on port " + properties.getProperty("listener.port") + "...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Incoming email received.");

                // Get the email message from the socket
                InputStream is = socket.getInputStream();
                Message message = new MimeMessage(session, is);

                // Modify the From header
                message.setFrom(new InternetAddress(senderEmail));

                // Extract relevant information from the email message for logging
                String receiver = message.getAllRecipients()[0].toString();
                String subject = message.getSubject();
                String body = message.getContent().toString();

                // Write the relevant email content to the log file
                String logFileName = properties.getProperty("log.file");
                try (FileWriter writer = new FileWriter(logFileName, true)) {
                    writer.write("\n=========================\n");
                    writer.write("Received: " + message.getSentDate() + "\n");
                    writer.write("From: " + message.getFrom()[0] + "\n");
                    writer.write("To: " + receiver + "\n");
                    writer.write("Subject: " + subject + "\n");
                    writer.write("Content: " + body + "\n");
                } catch (IOException | MessagingException e) {
                    e.printStackTrace();
                }

                // Forward the email message
                Transport.send(message);

                System.out.println("Email forwarded successfully.");
                socket.close();
            }
        } catch (IOException | MessagingException e) {
            e.printStackTrace();
        }
    }
}
